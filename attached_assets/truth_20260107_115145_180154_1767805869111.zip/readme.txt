Bible SuperSearch Bible Export

SQLite
SQLite 3 database


These Bibles are legally shareable and reshareable for non-commercial purposes.  Please share them with others.

Please see the copyright statement on each Bible for more information.

These files are provided as-is and without warranty.


Index of Bibles Included: 

File                                        Bible
================================================================================================================================================================


ES-Español   (Spanish)
--------------------------------------------------------------------------------------------------------------------------------------------
* rv_1858.sqlite -------------------------- Reina Valera 1858 NT
* rv_1909.sqlite -------------------------- Reina Valera 1909
* rv_1909_strongs.sqlite ------------------ Reina-Valera 1909 w/Strong's
* rvg.sqlite ------------------------------ Reina Valera Gómez (2023)
* sagradas.sqlite ------------------------- Sagradas Escrituras (1569)


FR-Français   (French)
--------------------------------------------------------------------------------------------------------------------------------------------
* segond_1910.sqlite ---------------------- Louis Segond 1910


HT-Kreyòl_Ayisyen   (Haitian, Haitian Creole)
--------------------------------------------------------------------------------------------------------------------------------------------
* hcv.sqlite ------------------------------ Haitian Creole Version 


